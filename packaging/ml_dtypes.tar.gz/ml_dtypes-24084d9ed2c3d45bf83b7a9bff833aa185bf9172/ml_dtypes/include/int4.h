#ifndef THIRD_PARTY_PY_ML_DTYPES_INCLUDE_INT4_H_
#define THIRD_PARTY_PY_ML_DTYPES_INCLUDE_INT4_H_

// IWYU pragma: begin_exports
#include "include/intn.h"  // INLINER_FORWARD_TO
// IWYU pragma: end_exports

#endif  // THIRD_PARTY_PY_ML_DTYPES_INCLUDE_INT4_H_
